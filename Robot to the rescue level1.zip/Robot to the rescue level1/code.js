var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["20d600f2-76e8-4e89-ac17-1946204e8b3c","d735aeed-43f2-46f1-9683-e907e85673d2","db45ce2a-1221-48ed-80ac-bc90f403f1ef","fd90df4b-b8a7-46cb-81c7-b2c3f4ef0f1d","c17f6487-266d-46f1-9601-2718c245d13a","cf322d18-64f6-41e2-82f0-de688f1a99fe","c377eaa7-eb99-46d6-af53-5395bf98ae05","0dac4294-cc7d-452f-a121-86b2cb38db51","30556d7b-bc31-4801-a2ee-a87d4b2ecb2c","9c7d3cc3-2d40-4b73-9c58-8a801731333b","eb69dabc-675f-47a3-9206-57c02f3b44eb"],"propsByKey":{"20d600f2-76e8-4e89-ac17-1946204e8b3c":{"name":"download.png_1","sourceUrl":null,"frameSize":{"x":172,"y":192},"frameCount":2,"looping":true,"frameDelay":12,"version":"vayi6LZQaci5kYzayrWEjRj.nNl5diTT","loadedFromSource":true,"saved":true,"sourceSize":{"x":172,"y":384},"rootRelativePath":"assets/20d600f2-76e8-4e89-ac17-1946204e8b3c.png"},"d735aeed-43f2-46f1-9683-e907e85673d2":{"name":"download.png_1_copy_1","sourceUrl":null,"frameSize":{"x":172,"y":192},"frameCount":1,"looping":true,"frameDelay":12,"version":"QPIOvv1qPwCa.b9hewFb_R2Q2mYOhNCC","loadedFromSource":true,"saved":true,"sourceSize":{"x":172,"y":192},"rootRelativePath":"assets/d735aeed-43f2-46f1-9683-e907e85673d2.png"},"db45ce2a-1221-48ed-80ac-bc90f403f1ef":{"name":"images (7).jpg_1","sourceUrl":"assets/v3/animations/tsFrjp6-GuEGt3pW4JpMTBINpb5k1-WpmQRs6MCS3F0/db45ce2a-1221-48ed-80ac-bc90f403f1ef.png","frameSize":{"x":267,"y":189},"frameCount":1,"looping":true,"frameDelay":4,"version":"mSOWrD9EssxNBMe2KHS0sT7TsH4XxwBL","loadedFromSource":true,"saved":true,"sourceSize":{"x":267,"y":189},"rootRelativePath":"assets/v3/animations/tsFrjp6-GuEGt3pW4JpMTBINpb5k1-WpmQRs6MCS3F0/db45ce2a-1221-48ed-80ac-bc90f403f1ef.png"},"fd90df4b-b8a7-46cb-81c7-b2c3f4ef0f1d":{"name":"bronze_1","sourceUrl":"assets/api/v1/animation-library/gamelab/RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY/category_board_games_and_cards/bronze.png","frameSize":{"x":86,"y":86},"frameCount":6,"looping":true,"frameDelay":2,"version":"RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":516,"y":86},"rootRelativePath":"assets/api/v1/animation-library/gamelab/RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY/category_board_games_and_cards/bronze.png"},"c17f6487-266d-46f1-9601-2718c245d13a":{"name":"retro_red_heart_1","sourceUrl":null,"frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":12,"version":"HzVUdD7akC61JgJSLLYmFer.aJwas_wG","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/c17f6487-266d-46f1-9601-2718c245d13a.png"},"cf322d18-64f6-41e2-82f0-de688f1a99fe":{"name":"retro_red_heart_1_copy_1","sourceUrl":null,"frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":12,"version":"O_J3mbr45yDvssxh4OZrIZZO.m3g2gJw","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/cf322d18-64f6-41e2-82f0-de688f1a99fe.png"},"c377eaa7-eb99-46d6-af53-5395bf98ae05":{"name":"retro_red_heart_1_copy_1_copy_1","sourceUrl":null,"frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":12,"version":"35XJjMgq0f2ndo.kUTrhDrbJkzygQalr","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/c377eaa7-eb99-46d6-af53-5395bf98ae05.png"},"0dac4294-cc7d-452f-a121-86b2cb38db51":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"m4hy47dKghObV33cjC6EqrszDSRIVmiZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/0dac4294-cc7d-452f-a121-86b2cb38db51.png"},"30556d7b-bc31-4801-a2ee-a87d4b2ecb2c":{"name":"gameplayadventure_13_1","sourceUrl":"assets/api/v1/animation-library/gamelab/k6jtclaZiYE1rnBGvIcDXcZXc_WDoMiM/category_game_blocks/gameplayadventure_13.png","frameSize":{"x":328,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"k6jtclaZiYE1rnBGvIcDXcZXc_WDoMiM","categories":["game_blocks"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":328,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/k6jtclaZiYE1rnBGvIcDXcZXc_WDoMiM/category_game_blocks/gameplayadventure_13.png"},"9c7d3cc3-2d40-4b73-9c58-8a801731333b":{"name":"animation_2","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":2,"looping":true,"frameDelay":12,"version":"kfOr4e0E6jHeJgKk441ELtndnB0Mx.XQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":200},"rootRelativePath":"assets/9c7d3cc3-2d40-4b73-9c58-8a801731333b.png"},"eb69dabc-675f-47a3-9206-57c02f3b44eb":{"name":"animation_3","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"qFshzR_UNjZ0zpixtK9u97glM0t7c6yb","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/eb69dabc-675f-47a3-9206-57c02f3b44eb.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

text("Click on the arrow keys to move the robot and get into the pordal to level up.", 25, 15);
playSound("assets/War-Robot-short-escape-fail!.mp3", true);
createEdgeSprites();
var floor1 = createSprite(120, 90);
floor1.setAnimation("images (7).jpg_1");
floor1.height =60;
floor1.width = 300;
var floor2 = createSprite(250, 208);
floor2.setAnimation("images (7).jpg_1");
floor2.height =60;
floor2.width = 300;
var floor3 = createSprite(120, 336);
floor3.setAnimation("images (7).jpg_1");
floor3.height =60;
floor3.width = 300;
var lives3 = createSprite(341, 40);
lives3.setAnimation("retro_red_heart_1_copy_1_copy_1");
lives3.height =60;
lives3.width = 50;
var player = createSprite(27, 26);
player.setAnimation("download.png_1");
player.height =60;
player.width = 50;
var coin1 = createSprite(337, 138);
coin1.setAnimation("bronze_1");
coin1.height =60;
coin1.width = 50;
var coin2 = createSprite(22, 149);
coin2.setAnimation("bronze_1");
coin2.height =60;
coin2.width = 50;
var pordal = createSprite(376, 306);
pordal.setAnimation("animation_1");
pordal.height =150;
pordal.width = 150;
var danger = createSprite(366, 133);
danger.setAnimation("gameplayadventure_13_1");
danger.height =50;
danger.width = 50;
drawSprites();
danger.velocityX = 15;
function draw() {
  danger.bounceOff(leftEdge);
  danger.bounceOff(rightEdge);
  background("cyan");
  drawSprites();
  player.collide(floor1);
  player.collide(floor2);
  player.collide(floor3);
  if (keyDown("up")) {
    player.y = player.y - 10;
  }
  if (keyDown("down")) {
    player.y = player.y + 10;
  }
  if (keyDown("left")) {
    player.setAnimation("download.png_1_copy_1");
    player.x = player.x - 10;
  }
  if (keyDown("right")) {
    player.setAnimation("download.png_1");
    player.x = player.x + 10;
  }
  if (player.isTouching(coin1)) {
    coin1.x = 1000;
    playSound("assets/category_bell/hollow_bell_notification.mp3", false);
  }
  if (player.isTouching(coin2)) {
    coin2.x = 1000;
    playSound("assets/category_bell/hollow_bell_notification.mp3", false);
  }
  if (player.isTouching(danger)) {
    
  }
  if (player.isTouching(pordal)) {
    player.x = 1000;
    playSound("assets/category_achievements/retro_game_classic_power_up_3.mp3", false);
    stopSound("assets/War-Robot-short-escape-fail!.mp3");
    playSound("assets/you won.mp3", true);
    playSound("assets/blah blah.mp3", false);
  }
 /* if (danger.isTouching(rightEdge)) {
    danger.x = danger.x + 5;
  }
  if (danger.isTouching(leftEdge)) {
    danger.x = danger.x - 5;
  } */
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
